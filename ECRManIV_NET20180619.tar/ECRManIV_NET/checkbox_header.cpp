#include "checkbox_header.h"

checkbox_header::checkbox_header(QObject *parent) : QObject(parent)
{

}

checkbox_header::~checkbox_header()
{

}

