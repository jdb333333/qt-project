#include "clerk.h"

clerk::clerk(QObject *parent) : QObject(parent)
{

}

clerk::~clerk()
{

}

